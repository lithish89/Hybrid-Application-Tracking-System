import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import ApplicantPage from './pages/ApplicantPage'
import AdminPage from './pages/AdminDashboard'
import BotMimicPage from './pages/BotMimicPage'
import Nav from './components/Nav'
import ProtectedRoute from './components/ProtectedRoute'

export default function App() {
  return (
    <div className='app'>
      <Nav />
      <main className='container'>
        <Routes>
          <Route path='/' element={<Navigate to='/dashboard' replace />} />
          <Route path='/login' element={<Login />} />
          <Route path='/register' element={<Register />} />
          <Route path='/dashboard' element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
          <Route path='/applicant' element={<ProtectedRoute role='applicant'><ApplicantPage /></ProtectedRoute>} />
          <Route path='/admin' element={<ProtectedRoute role='admin'><AdminPage /></ProtectedRoute>} />
          <Route path='/bot' element={<ProtectedRoute role='bot'><BotMimicPage /></ProtectedRoute>} />
          <Route path='*' element={<div>404 Not Found</div>} />
        </Routes>
      </main>
    </div>
  )
}
