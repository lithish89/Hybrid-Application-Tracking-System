import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

export default function Nav() {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const role = localStorage.getItem('role');

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    navigate('/login', { replace: true });
  };

  const getDashboardLink = () => {
    switch (role) {
      case 'admin':
        return '/admin';
      case 'bot':
        return '/bot';
      case 'applicant':
      default:
        return '/dashboard';
    }
  };

  return (
    <nav className='nav'>
      <div className='nav-left'>
        <Link to={getDashboardLink()} className='brand'>
          Hybrid ATS
        </Link>
      </div>
      <div className='nav-right'>
        {token ? (
          <>
            {role === 'applicant' && <Link to='/dashboard'>Dashboard</Link>}
            {role === 'applicant' && <Link to='/applicant'>My Applications</Link>}
            {role === 'admin' && <Link to='/admin'>Admin</Link>}
            {role === 'bot' && <Link to='/bot'>Bot Mimic</Link>}
            <button onClick={logout} className='btn small'>Logout</button>
          </>
        ) : (
          <Link to='/login'>Login</Link>
        )}
      </div>
    </nav>
  );
}
