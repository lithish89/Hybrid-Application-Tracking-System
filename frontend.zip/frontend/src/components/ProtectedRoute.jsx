import React from 'react'
import { Navigate } from 'react-router-dom'

export default function ProtectedRoute({ children, role }){
  const token = localStorage.getItem('token')
  const userRole = localStorage.getItem('role')
  if(!token) return <Navigate to='/login' replace />
  if(role && role!==userRole) return <div className='unauth'>Not authorized for this page</div>
  return children
}
