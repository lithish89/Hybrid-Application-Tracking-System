import React, { useEffect, useState } from "react";
import api from "../api";

export default function BotMimicPage() {
  const [apps, setApps] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  // Load all applications
  const loadApps = async () => {
    try {
      const res = await api.getApplications();
      const techApps = res.data.filter(a => a.role === "technical");
      setApps(techApps);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadApps();
  }, []);

  // Trigger bot for all technical applications
  const handleBotTrigger = async () => {
    try {
      setLoading(true);
      setMessage("");
      const res = await api.triggerBot();
      setMessage(`${res.data.updatedCount} technical applications updated.`);
      await loadApps(); // reload apps after update
    } catch (err) {
      console.error(err);
      setMessage("Failed to update applications.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="card">
      <h2>Bot Mimic</h2>
      <p>Operates only on technical applications. Click below to update their status to the next stage.</p>
      <button className="btn" onClick={handleBotTrigger} disabled={loading}>
        {loading ? "Updating..." : "Update Technical Applications"}
      </button>
      {message && <p>{message}</p>}

      <h3 style={{ marginTop: "20px" }}>Technical Applications</h3>
      <ul className="list">
        {apps.map(a => (
          <li key={a._id} className="list-item">
            <div><strong>{a.applicantName || "Applicant"}</strong></div>
            <div>Status: {a.status}</div>
            <div className="meta">Last activity: {new Date(a.updatedAt).toLocaleString()}</div>
          </li>
        ))}
      </ul>
    </div>
  );
}
