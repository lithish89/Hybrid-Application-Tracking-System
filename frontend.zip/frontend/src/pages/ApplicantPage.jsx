import React, {useEffect, useState} from 'react'
import api from '../api'

export default function ApplicantPage(){
  const [apps,setApps]=useState([])
  const [form,setForm]=useState({ role:'technical', jobId:'', candidateName:'' })
  useEffect(()=>{ load() },[])
  async function load(){
    try{ const res=await api.getApplications({}); setApps(res.data) }catch(e){ console.error(e) }
  }
  async function submit(e){
    e.preventDefault()
    try{ await api.createApplication(form); setForm({role:'technical', jobId:'', candidateName:''}); load() }catch(e){ console.error(e) }
  }
  async function addComment(id){
    const note = prompt('Add a note/comment')
    if(!note) return
    await api.addComment(id, { text: note })
    load()
  }
  return (
    <div className='card'>
      <h2>My Applications</h2>
      <form onSubmit={submit} className='form-inline'>
        <input placeholder='Candidate name' value={form.candidateName} onChange={e=>setForm({...form,candidateName:e.target.value})} required/>
        <select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
          <option value='technical'>Technical</option>
          <option value='non-technical'>Non-Technical</option>
        </select>
        <button className='btn' type='submit'>Create</button>
      </form>
      <ul className='list'>
        {apps.map(a=>(
          <li key={a._id} className='list-item'>
            <div><strong>{a.candidateName}</strong> — <em>{a.role}</em></div>
            <div>Status: {a.status}</div>
            <div className='meta'>Created: {new Date(a.createdAt).toLocaleString()}</div>
            <button className='btn small' onClick={()=>addComment(a._id)}>Add Comment</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
