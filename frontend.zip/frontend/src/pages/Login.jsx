import React, { useState } from 'react';
import api from '../api';
import { useNavigate, Link } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.login({ email, password });
      const role = res.data?.role;
      const token = res.data?.token;

      if (!role || !token) {
        setErr('Login failed: Invalid response from server');
        return;
      }

      localStorage.setItem('role', role);
      localStorage.setItem('token', token);

      // Redirect based on role
      switch (role) {
        case 'admin':
          navigate('/admin', { replace: true });
          break;
        case 'bot':
          navigate('/bot', { replace: true });
          break;
        case 'applicant':
        default:
          navigate('/dashboard', { replace: true });
      }
    } catch (error) {
      console.error(error);
      setErr(error.response?.data?.message || 'Something went wrong. Please try again.');
    }
  };

  return (
    <div className="card centered">
      <h2>Login</h2>
      <form onSubmit={submit} className="form">
        <label>
          Email
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <button className="btn" type="submit">Login</button>
        {err && <p className="error">{err}</p>}
      </form>
      <p className="muted">
        New user? <Link to="/register">Register</Link>
      </p>
      <p className="muted">Sample credentials: admin@example.com / password</p>
    </div>
  );
}
