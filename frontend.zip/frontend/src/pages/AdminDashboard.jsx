// frontend/src/pages/AdminDashboard.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function AdminDashboard() {
  const navigate = useNavigate();

  // State
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [jobTitle, setJobTitle] = useState("");
  const [jobRole, setJobRole] = useState("technical");
  const [err, setErr] = useState("");

  const [stats, setStats] = useState({
    total: 0,
    byStatus: {},
    byRole: { technical: 0, "non-technical": 0 },
  });

  // Redirect non-admins
  useEffect(() => {
    const role = localStorage.getItem("role");
    if (role !== "admin") {
      alert("You are not authorized to view this page.");
      navigate("/dashboard");
    }
  }, [navigate]);

  // Load jobs & applications
  useEffect(() => {
    loadJobs();
    loadApplications();
  }, []);

  const loadJobs = async () => {
    try {
      const res = await api.getJobs();
      const jobList = Array.isArray(res.data) ? res.data : res.data.jobs || [];
      setJobs(jobList);
    } catch (error) {
      console.error(error);
      setErr("Failed to load jobs");
      setJobs([]);
    }
  };

  const loadApplications = async () => {
    try {
      const res = await api.getApplications();
      const apps = Array.isArray(res.data) ? res.data : res.data.applications || [];
      setApplications(apps);

      const byStatus = apps.reduce((acc, app) => {
        acc[app.status] = (acc[app.status] || 0) + 1;
        return acc;
      }, {});

      const byRole = apps.reduce(
        (acc, app) => {
          acc[app.role] = (acc[app.role] || 0) + 1;
          return acc;
        },
        { technical: 0, "non-technical": 0 }
      );

      setStats({ total: apps.length, byStatus, byRole });
    } catch (error) {
      console.error(error);
      setErr("Failed to load applications");
      setApplications([]);
      setStats({ total: 0, byStatus: {}, byRole: { technical: 0, "non-technical": 0 } });
    }
  };

  // Create new job
  const createJob = async (e) => {
    e.preventDefault();
    if (!jobTitle) return setErr("Job title is required");
    try {
await api.createJob({
  title: jobTitle,
  category: jobRole,       // "technical" or "non-technical"
  roles: [{ name: jobRole, openings: 1 }]

});
      setJobTitle("");
      setJobRole("technical");
      loadJobs();
      setErr("");
    } catch (error) {
      console.error(error);
      setErr(error.response?.data?.message || "Failed to create job");
    }
  };

  // Delete job
  const deleteJob = async (id) => {
    if (!window.confirm("Are you sure you want to delete this job?")) return;
    try {
      await api.deleteJob(id);
      loadJobs();
    } catch (error) {
      console.error(error);
      setErr(error.response?.data?.message || "Failed to delete job");
    }
  };

  const applyJob = async (jobId) => {
  try {
    await api.createApplication({ jobId }); // or api.applyToJob(jobId)
    alert("Applied successfully!");
    loadApplications();
  } catch (err) {
    console.error(err);
    alert(err.response?.data?.message || "Failed to apply");
  }
};


  // Update application status
  const updateStatus = async (appId, newStatus) => {
    try {
      await api.updateApplication(appId, { status: newStatus });
      loadApplications();
    } catch (error) {
      console.error(error);
      setErr(error.response?.data?.message || "Failed to update application status");
    }
  };

  // Chart data
  const statusLabels = Object.keys(stats.byStatus);
  const statusData = {
    labels: statusLabels,
    datasets: [
      {
        label: "Applications by Status",
        data: statusLabels.map((l) => stats.byStatus[l] || 0),
        backgroundColor: "rgba(75, 192, 192, 0.6)",
      },
    ],
  };

  const roleLabels = Object.keys(stats.byRole);
  const roleData = {
    labels: roleLabels,
    datasets: [
      {
        label: "Applications by Role",
        data: roleLabels.map((l) => stats.byRole[l] || 0),
        backgroundColor: ["rgba(54, 162, 235, 0.6)", "rgba(255, 159, 64, 0.6)"],
      },
    ],
  };

  return (
    <div className="admin-dashboard">
      {err && <p style={{ color: "red" }}>{err}</p>}

      {/* Create Job */}
      <div className="card">
        <h2>Create New Job Opening</h2>
        <form onSubmit={createJob}>
          <input
            type="text"
            placeholder="Job Title"
            value={jobTitle}
            onChange={(e) => setJobTitle(e.target.value)}
            required
          />
          <select value={jobRole} onChange={(e) => setJobRole(e.target.value)}>
            <option value="technical">Technical</option>
            <option value="non-technical">Non-Technical</option>
          </select>
          <button type="submit">Create Job</button>
        </form>
      </div>

      {/* Job List */}
      <div className="card">
        <h2>Job Openings</h2>
        {jobs.length === 0 ? (
          <p>No jobs created yet.</p>
        ) : (
          <ul>
            {jobs.map((job) => (
              <li key={job._id}>
                {job.title} ({job.role}){" "}
                <button onClick={() => deleteJob(job._id)}>Delete</button>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Charts */}
      <div className="card">
        <h2>Stats & Charts</h2>
        <p>Total Applications: {stats.total}</p>

        <div className="chart">
          <h4>Applications by Status</h4>
          {statusLabels.length > 0 ? <Bar data={statusData} /> : <p>No status data yet.</p>}
        </div>

        <div className="chart">
          <h4>Applications by Role</h4>
          {roleLabels.length > 0 ? <Bar data={roleData} /> : <p>No role data yet.</p>}
        </div>
      </div>

      {/* Applications List */}
      <div className="card">
        <h2>Applications</h2>
        {applications.length === 0 ? (
          <p>No applications yet.</p>
        ) : (
          <table border={1} style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Role</th>
                <th>Applied For</th>
                <th>Update Status</th>
              </tr>
            </thead>
            <tbody>
              {applications.map((app) => (
                <tr key={app._id}>
                  <td>{app.name}</td>
                  <td>{app.status}</td>
                  <td>{app.role}</td>
                  <td>{app.applicationRole}</td>
                  <td>
                    {app.role === "non-technical" ? (
                      <select
                        value={app.status}
                        onChange={(e) => updateStatus(app._id, e.target.value)}
                      >
                        <option value="applied">Applied</option>
                        <option value="interview_round">Interview Round</option>
                        <option value="review">Review</option>
                        <option value="approver">Approver</option>
                      </select>
                    ) : (
                      <span>Cannot update</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
