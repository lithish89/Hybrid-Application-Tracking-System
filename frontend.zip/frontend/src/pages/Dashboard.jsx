// frontend/src/pages/Dashboard.jsx
import React, { useEffect, useState } from "react";
import api from "../api";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from "chart.js";
import { Bar } from "react-chartjs-2";

ChartJS.register(CategoryScale, LinearScale, BarElement, Title, Tooltip, Legend);

export default function Dashboard() {
  const [stats, setStats] = useState({
    total: 0,
    byStatus: {},
    byRole: { technical: 0, "non-technical": 0 },
  });
  const [applications, setApplications] = useState([]);
  const [jobs, setJobs] = useState([]);
  const [error, setError] = useState("");

  const token = localStorage.getItem("token");
  const parseJwt = (token) => {
    try { return JSON.parse(atob(token.split(".")[1])); } catch { return null; }
  };
  const userId = parseJwt(token)?.id;

  // Load jobs and user applications
  useEffect(() => {
    const loadData = async () => {
      try {
        const jobsRes = await api.getJobs();
        const jobsList = Array.isArray(jobsRes.data) ? jobsRes.data : jobsRes.data.jobs || [];
        setJobs(jobsList);

        const appsRes = await api.getMyApplications();
        const userApps = appsRes.data.applications || [];
        setApplications(userApps);

        const byStatus = userApps.reduce((acc, a) => {
          acc[a.status] = (acc[a.status] || 0) + 1; return acc;
        }, {});
        const byRole = userApps.reduce((acc, a) => {
          acc[a.role] = (acc[a.role] || 0) + 1; return acc;
        }, { technical: 0, "non-technical": 0 });

        setStats({ total: userApps.length, byStatus, byRole });
      } catch (err) {
        console.error(err);
        setError("Failed to load data");
      }
    };
    loadData();
  }, [userId]);

  const applyJob = async (job) => {
    try {
      await api.applyToJob(job._id); // <-- use applyToJob endpoint
      alert(`Applied to ${job.title}!`);

      // Reload applications
      const appsRes = await api.getMyApplications();
      const userApps = appsRes.data.applications || [];
      setApplications(userApps);

      const byStatus = userApps.reduce((acc, a) => {
        acc[a.status] = (acc[a.status] || 0) + 1; return acc;
      }, {});
      const byRole = userApps.reduce((acc, a) => {
        acc[a.role] = (acc[a.role] || 0) + 1; return acc;
      }, { technical: 0, "non-technical": 0 });
      setStats({ total: userApps.length, byStatus, byRole });
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.message || "Failed to apply");
    }
  };

  const statusLabels = Object.keys(stats.byStatus);
  const roleLabels = Object.keys(stats.byRole);

  const statusData = {
    labels: statusLabels,
    datasets: [{
      label: "Applications by Status",
      data: statusLabels.map(l => stats.byStatus[l] || 0),
      backgroundColor: "rgba(75, 192, 192, 0.6)"
    }]
  };
  const roleData = {
    labels: roleLabels,
    datasets: [{
      label: "Applications by Role",
      data: roleLabels.map(l => stats.byRole[l] || 0),
      backgroundColor: ["rgba(54, 162, 235, 0.6)", "rgba(255, 159, 64, 0.6)"]
    }]
  };

  return (
    <div className="card">
      <h2>Dashboard</h2>
      {error && <p style={{ color: "red" }}>{error}</p>}

      <div className="grid">
        <div className="stat">
          <h3>Total Applications</h3>
          <p className="big">{stats.total}</p>
        </div>
        <div className="chart">
          <h4>Applications by Status</h4>
          {statusLabels.length > 0 ? <Bar data={statusData} /> : <p>No status data yet.</p>}
        </div>
        <div className="chart">
          <h4>Applications by Role</h4>
          {roleLabels.length > 0 ? <Bar data={roleData} /> : <p>No role data yet.</p>}
        </div>
      </div>

      {/* Job Openings */}
      <div className="card" style={{ marginTop: "20px" }}>
        <h3>Job Openings</h3>
        {jobs.length === 0 ? <p>No job openings yet.</p> : (
          <ul>
            {jobs.map(job => {
              const alreadyApplied = applications.some(app => app.jobId._id === job._id);
              return (
                <li key={job._id}>
                  {job.title} ({job.category}){" "}
                  <button onClick={() => applyJob(job)} disabled={alreadyApplied}>
  {alreadyApplied ? "Applied" : "Apply"}
</button>

                </li>
              );
            })}
          </ul>
        )}
      </div>

      {/* Candidate Applications */}
      <div className="card" style={{ marginTop: "20px" }}>
        <h3>My Applications</h3>
        {applications.length === 0 ? <p>No applications yet.</p> : (
          <table border={1} style={{ width: "100%", borderCollapse: "collapse" }}>
  <thead>
    <tr>
      <th>Job Title</th>
      <th>Status</th>
      <th>Role</th>
    </tr>
  </thead>
  <tbody>
    {applications.map(app => (
      <tr key={app._id}>
        <td>{app.jobId?.title || "N/A"}</td>
        <td>{app.status}</td>
        <td>{app.role || "N/A"}</td>

      </tr>
    ))}
  </tbody>
</table>

        )}
      </div>
    </div>
  );
}
