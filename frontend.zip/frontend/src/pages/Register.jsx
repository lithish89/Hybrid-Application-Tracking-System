import React, { useState } from 'react';
import api from '../api';
import { useNavigate } from 'react-router-dom';

export default function Register() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('applicant'); // Only admin or applicant
  const [err, setErr] = useState('');
  const [success, setSuccess] = useState('');
  const navigate = useNavigate();

  const submit = async (e) => {
    e.preventDefault();
    try {
      const res = await api.register({ name, email, password, role });
      if (res.data?.token) {
        setSuccess('Registration successful! Redirecting to login...');
        setTimeout(() => navigate('/login'), 1500);
      }
    } catch (error) {
      console.error(error);
      setErr(error.response?.data?.message || 'Failed to register');
    }
  };

  return (
    <div className="card centered">
      <h2>Register</h2>
      <form onSubmit={submit} className="form">
        <label>
          Name
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </label>
        <label>
          Email
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </label>
        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </label>
        <label>
          Role
          <select value={role} onChange={(e) => setRole(e.target.value)}>
            <option value="applicant">User</option>
            <option value="admin">Admin</option>
          </select>
        </label>
        <button className="btn" type="submit">Register</button>
        {err && <p className="error">{err}</p>}
        {success && <p className="success">{success}</p>}
      </form>
    </div>
  );
}
