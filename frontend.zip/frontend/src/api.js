// frontend/src/api.js
import axios from "axios";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:5000/api";

const client = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
});

// Attach token if present
client.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export default {
  // Auth
  login: (data) => client.post("/users/login", data),
  register: (data) => client.post("/users/register", data),
  me: () => client.get("/users/profile"),

  // Jobs
  getJobs: () => client.get("/jobs"),
  createJob: (data) => client.post("/jobs", data),
  deleteJob: (id) => client.delete(`/jobs/${id}`),

  // Applications
  applyToJob: (jobId) => client.post(`/applications/apply/${jobId}`),
  getMyApplications: () => client.get("/applications/my"),
  deleteApplication: (id) => client.delete(`/applications/${id}`),
  getApplications: () => client.get("/applications"), // admin: all applications
  triggerBot: () => client.post("/applications/bot/trigger"), // trigger bot for all technical apps

  // Bot
  triggerBot: (status) => client.post("/applications/bot/trigger", { status }),
};
