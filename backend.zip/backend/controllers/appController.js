// backend/controllers/appController.js
import Application from "../models/applicationModel.js";
import Job from "../models/jobModel.js";
import { sendEmail } from "../utils/email.js";

// Apply to a job
export const applyToJob = async (req, res) => {
  try {
    const notes = req.body?.notes || "";
    const jobId = req.params.id;

    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const existingApp = await Application.findOne({ jobId, applicant: req.user._id });
    if (existingApp) return res.status(400).json({ message: "Already applied" });

    const application = await Application.create({
      applicant: req.user._id,
      jobId,
      role: req.user.role,
      history: [{ status: "Applied", comment: "Application submitted", updatedBy: "applicant" }],
      notes,
    });

    await sendEmail({
      to: req.user.email,
      subject: `✅ Application Submitted: ${job.title}`,
      text: `Hello ${req.user.name}, your application for "${job.title}" has been submitted.`,
    });

    res.status(201).json(application);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: error.message });
  }
};

// Get candidate applications
export const getMyApplications = async (req, res) => {
  try {
    const applications = await Application.find({ applicant: req.user._id })
      .populate("jobId")
      .sort({ createdAt: -1 });

    res.json({ applications });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};

// Get all applications (admin)
export const getAllApplications = async (req, res) => {
  try {
    const applications = await Application.find().populate("jobId");
    res.json(applications);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};

// Update application status (admin)
export const updateApplicationStatus = async (req, res) => {
  try {
    const { status, comment } = req.body;
    const app = await Application.findById(req.params.id).populate("jobId");
    if (!app) return res.status(404).json({ message: "Application not found" });

    if (app.role === "technical")
      return res.status(403).json({ message: "Cannot update technical app via admin" });

    app.status = status || app.status;
    if (comment) app.notes = comment;
    app.history.push({ status: app.status, comment: comment || "", updatedBy: "admin" });
    await app.save();

    res.json(app);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};

// Delete candidate application
export const deleteApplication = async (req, res) => {
  try {
    const app = await Application.findById(req.params.id);
    if (!app) return res.status(404).json({ message: "Application not found" });

    if (app.applicant.toString() !== req.user._id.toString())
      return res.status(403).json({ message: "Not authorized" });

    await app.remove();
    res.json({ message: "Application deleted" });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};

// Bot Mimic: Update all technical applications to next status
export const triggerBot = async (req, res) => {
  try {
    // Define status flow
    const statusFlow = ["Applied", "Screening", "Interview", "Offer", "Hired"];
    
    // Fetch all technical applications
    const apps = await Application.find({ role: "technical" }).populate("jobId");

    const updatedApps = [];

    for (const app of apps) {
      const currentIndex = statusFlow.indexOf(app.status);
      if (currentIndex < statusFlow.length - 1) {
        const nextStatus = statusFlow[currentIndex + 1];
        app.status = nextStatus;
        app.history.push({
          status: nextStatus,
          comment: "Bot updated status",
          updatedBy: "bot",
        });
        await app.save();
        updatedApps.push(app);
      }
    }

    res.json({ message: "Bot triggered", updated: updatedApps.length, applications: updatedApps });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: err.message });
  }
};
