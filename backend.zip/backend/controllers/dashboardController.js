import Application from "../models/applicationModel.js";
import Job from "../models/jobModel.js";

export const getDashboardStats = async (req, res) => {
  try {
    // Total applications
    const totalApplications = await Application.countDocuments();

    // Applications by status
    const statusCounts = await Application.aggregate([
      { $group: { _id: "$status", count: { $sum: 1 } } }
    ]);

    // Applications by job type
    const jobs = await Job.find();
    const jobMap = {};
    jobs.forEach(job => { jobMap[job._id] = job.category === "technical"; });

    const applications = await Application.find();
    let technicalCount = 0;
    let nonTechnicalCount = 0;
    applications.forEach(app => {
      if (jobMap[app.jobId]) technicalCount++;
      else nonTechnicalCount++;
    });

    // Applications per role (last update)
    const roleCounts = await Application.aggregate([
      { $project: { lastUpdatedBy: { $arrayElemAt: ["$history.updatedBy", -1] } } },
      { $group: { _id: "$lastUpdatedBy", count: { $sum: 1 } } }
    ]);

    res.json({
      success: true,
      data: {
        totalApplications,
        statusCounts,
        technicalCount,
        nonTechnicalCount,
        roleCounts
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
