// backend/controllers/jobController.js
import Job from "../models/jobModel.js";

// Get all jobs
export const getJobs = async (req, res) => {
  try {
    const jobs = await Job.find();
    res.json(jobs);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Get a single job by ID
export const getJobById = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: "Job not found" });
    res.json(job);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Create a new job
export const createJob = async (req, res) => {
  try {
    const { title, description, department, category, roles } = req.body;

    if (!title || !roles || roles.length === 0) {
      return res.status(400).json({ message: "Title and roles are required" });
    }

    const job = await Job.create({ title, description, department, category, roles });
    res.status(201).json(job);
  } catch (error) {
    console.error("Create Job Error:", error);
    res.status(500).json({ message: error.message });
  }
};

// Delete a job
export const deleteJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: "Job not found" });
    await job.remove();
    res.json({ success: true, message: "Job deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

export const updateJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const { title, description, department, category, roles } = req.body;
    if (title) job.title = title;
    if (description) job.description = description;
    if (department) job.department = department;
    if (category) job.category = category;
    if (roles && roles.length > 0) job.roles = roles;

    await job.save();
    res.json({ success: true, job });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};