// controllers/applicationController.js
import Application from "../models/applicationModel.js";
import Job from "../models/jobModel.js";
import User from "../models/userModel.js";

// Candidate applies to a job
export const applyToJob = async (req, res) => {
  const { jobId, role } = req.body;
  try {
    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const appExists = await Application.findOne({ applicant: req.user._id, jobId, role });
    if (appExists) return res.status(400).json({ message: "Already applied" });

    const application = await Application.create({
      applicant: req.user._id,
      jobId,
      role,
      history: [{ status: "Applied", updatedBy: req.user.role, comment: "Application submitted" }],
    });

    res.status(201).json({ success: true, application });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all applications (Admin)
export const getAllApplications = async (req, res) => {
  try {
    const applications = await Application.find()
      .populate("applicant", "name email role")
      .populate("jobId", "title category roles");
    res.json({ success: true, applications });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get candidate's applications
export const getMyApplications = async (req, res) => {
  try {
    const applications = await Application.find({ applicant: req.user._id })
      .populate("jobId", "title category roles");
    res.json({ success: true, applications });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Admin updates application status
export const updateApplicationStatus = async (req, res) => {
  const { status, comment } = req.body;
  try {
    const application = await Application.findById(req.params.applicationId);
    if (!application) return res.status(404).json({ message: "Application not found" });

    application.status = status;
    application.history.push({
      status,
      comment,
      updatedBy: req.user.role,
    });

    await application.save();
    res.json({ success: true, application });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Candidate deletes application
export const deleteApplication = async (req, res) => {
  try {
    const app = await Application.findById(req.params.id);
    if (!app) return res.status(404).json({ message: "Application not found" });
    if (app.applicant.toString() !== req.user._id.toString())
      return res.status(403).json({ message: "Cannot delete other's application" });

    await app.remove();
    res.json({ success: true, message: "Application deleted" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Bot Mimic automatic update
export const triggerMimicBotStatusUpdate = async (req, res) => {
  try {
    const apps = await Application.find()
      .populate("jobId", "title category roles")
      .populate("applicant", "name email");

    const technicalApps = apps.filter(app => app.jobId.category === "technical");

    for (const app of technicalApps) {
      const nextStatus = getNextStatus(app.status);
      if (!nextStatus) continue;

      app.status = nextStatus;
      app.history.push({ status: nextStatus, comment: "Automated Bot update", updatedBy: "Bot Mimic" });
      await app.save();
    }

    res.json({ success: true, message: "Bot updates triggered" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// Helper function for Bot workflow
const getNextStatus = (current) => {
  const workflow = ["Applied", "Under Review", "Interview Scheduled", "Selected"];
  const idx = workflow.indexOf(current);
  return idx >= 0 && idx < workflow.length - 1 ? workflow[idx + 1] : null;
};

// Create a new application
export const createApplication = async (req, res) => {
  try {
    const { jobId, applicationRole } = req.body;
    const userId = req.user._id; // from auth middleware

    if (!jobId || !applicationRole) {
      return res.status(400).json({ message: "Job ID and role required" });
    }

    // Check if already applied
    const exists = await Application.findOne({ job: jobId, user: userId });
    if (exists) return res.status(400).json({ message: "Already applied to this job" });

    const job = await Job.findById(jobId);
    if (!job) return res.status(404).json({ message: "Job not found" });

    const application = await Application.create({
      user: userId,
      job: jobId,
      jobTitle: job.title,
      status: "applied",
      applicationRole,
      role: applicationRole === "technical" ? "technical" : "non-technical",
    });

    res.status(201).json(application);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};

// Get all applications
export const getApplications = async (req, res) => {
  try {
    const applications = await Application.find().populate("user", "name email role");
    res.json(applications);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Server error" });
  }
};