import express from "express";
import { registerUser, loginUser, getUserProfile } from "../controllers/userController.js";
import { protect } from "../middlewares/authMiddleware.js";

const router = express.Router();

/* 🔐 Auth Routes */
router.post("/register", registerUser);       // Register new user
router.post("/login", loginUser);             // Login user
router.get("/profile", protect, getUserProfile); // Protected route to get user profile

export default router;
