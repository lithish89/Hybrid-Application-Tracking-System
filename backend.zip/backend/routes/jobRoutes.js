// backend/routes/jobRoutes.js
import express from "express";
import {
  getJobs,
  getJobById,
  createJob,
  updateJob,
  deleteJob,
} from "../controllers/jobController.js";
import { protect, admin } from "../middlewares/authMiddleware.js";

const router = express.Router();

// ✅ Anyone logged in can view all jobs
router.get("/", protect, getJobs);
router.get("/:id", protect, getJobById);

// ✅ Only admin can create, update, or delete jobs
router.post("/", protect, admin, createJob);
router.put("/:id", protect, admin, updateJob);
router.delete("/:id", protect, admin, deleteJob);

export default router;
