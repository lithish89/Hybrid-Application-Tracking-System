import express from "express";
import {
  applyToJob,
  getAllApplications,
  getMyApplications,
  updateApplicationStatus,
  deleteApplication,
  triggerBot, // <-- import new function
} from "../controllers/appController.js";

import { protect, admin } from "../middlewares/authMiddleware.js";

const router = express.Router();

// Candidate routes
router.post("/apply/:id", protect, applyToJob);
router.get("/my", protect, getMyApplications);
router.delete("/:id", protect, deleteApplication);

// Admin routes
router.get("/", protect, admin, getAllApplications);
router.put("/:id/status", protect, admin, updateApplicationStatus);
router.post("/bot/trigger", protect, triggerBot); // <-- new bot trigger route

export default router;
