import mongoose from "mongoose";

const roleSchema = mongoose.Schema({
  name: { type: String, required: true },
  openings: { type: Number, default: 1 },
});

const jobSchema = mongoose.Schema(
  {
    title: { type: String, required: true },
    description: { type: String },
    department: { type: String },
    category: { type: String, enum: ["technical", "non-technical"], default: "technical" },
    roles: [roleSchema],
  },
  { timestamps: true }
);

const Job = mongoose.model("Job", jobSchema);
export default Job;
