import mongoose from "mongoose";

const historySchema = mongoose.Schema({
  status: { type: String, required: true },
  comment: { type: String },
  updatedBy: { type: String, required: true }, // Admin / Bot Mimic / Applicant
  updatedAt: { type: Date, default: Date.now },
});

const applicationSchema = mongoose.Schema(
  {
    applicant: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    jobId: { type: mongoose.Schema.Types.ObjectId, ref: "Job", required: true },
    role: { type: String, required: true },
    status: { type: String, default: "Applied" },
    history: [historySchema],
  },
  { timestamps: true }
);

const Application = mongoose.model("Application", applicationSchema);
export default Application;
