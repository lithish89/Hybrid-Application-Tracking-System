export const validateFields = (fields = []) => {
  return (req, res, next) => {
    for (let field of fields) {
      if (!req.body[field]) return res.status(400).json({ message: `${field} is required` });
    }
    next();
  };
};

export const validateStatusUpdate = (req, res, next) => {
  const { status } = req.body;
  const validStatus = ["Pending", "Under Review", "Approved", "Rejected"];
  if (!status || !validStatus.includes(status)) {
    return res.status(400).json({ message: "Invalid or missing status value" });
  }
  next();
};
