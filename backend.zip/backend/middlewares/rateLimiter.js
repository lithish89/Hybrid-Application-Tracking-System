// middleware/rateLimiter.js
import rateLimit from "express-rate-limit";

// Limit API requests to prevent abuse
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // max 100 requests per IP per window
  message: {
    success: false,
    message: "Too many requests from this IP, please try again later.",
  },
});

export default apiLimiter;
