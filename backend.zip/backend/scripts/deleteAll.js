// backend/scripts/deleteAll.js
import mongoose from "mongoose";
import dotenv from "dotenv";

// Import your models
import User from "../models/userModel.js";
import Job from "../models/jobModel.js";
import Application from "../models/applicationModel.js";

dotenv.config();

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log("MongoDB connected");
  } catch (error) {
    console.error("MongoDB connection failed:", error.message);
    process.exit(1);
  }
};

// Developer function to delete all data
const deleteAllData = async () => {
  try {
    await User.deleteMany({});
    await Job.deleteMany({});
    await Application.deleteMany({});

    console.log("All data deleted from Users, Jobs, Applications collections");
    process.exit();
  } catch (error) {
    console.error("Error deleting data:", error.message);
    process.exit(1);
  }
};

// Run the script
const run = async () => {
  await connectDB();
  await deleteAllData();
};

run();
