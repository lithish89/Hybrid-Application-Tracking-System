// backend/scripts/deleteAllApplications.js
import dotenv from "dotenv";
import path from "path";
import connectDB from "../config/db.js";
import Application from "../models/applicationModel.js";
import readline from "readline";

// Load .env from backend folder
dotenv.config({ path: path.resolve("./../.env") });

// Function to prompt user for confirmation
const askConfirmation = (question) => {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      rl.close();
      resolve(answer.toLowerCase());
    });
  });
};

const main = async () => {
  try {
    // Connect to MongoDB
    await connectDB();

    const answer = await askConfirmation(
      "⚠️ Are you sure you want to DELETE ALL applications? Type 'yes' to confirm: "
    );
    if (answer !== "yes") {
      console.log("Operation cancelled.");
      process.exit(0);
    }

    await Application.deleteMany();
    console.log("✅ All applications deleted successfully");
    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

main();
