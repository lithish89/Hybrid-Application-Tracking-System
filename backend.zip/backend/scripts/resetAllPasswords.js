// backend/scripts/resetAllPasswords.js
import dotenv from "dotenv";
dotenv.config(); // load env first

import connectDB from "../config/db.js";
import User from "../models/userModel.js";

await connectDB(); // connect to MongoDB

import bcrypt from "bcryptjs";

const DEFAULT_PASSWORD = "Lithish_89"; // known password for testing

const reset = async () => {
  try {
    const users = await User.find();
    if (!users.length) {
      console.log("No users found to reset.");
      process.exit(0);
    }

    for (const user of users) {
      const salt = await bcrypt.genSalt(10);
      const hashed = await bcrypt.hash(DEFAULT_PASSWORD, salt);
      user.password = hashed;
      await user.save();
      console.log(`Reset password for ${user.email}`);
    }

    console.log(`All passwords reset to "${DEFAULT_PASSWORD}"`);
    process.exit(0);
  } catch (err) {
    console.error("Error resetting passwords:", err);
    process.exit(1);
  }
};

reset();
